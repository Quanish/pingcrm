<?php

namespace App\Http\Controllers;

use App\Models\Group;
use App\Models\GroupUser;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Request;
use Illuminate\Http\Request as ObjectRequest;
use Inertia\Inertia;

class GroupsController extends Controller
{
    public function index()
    {
        $groups = Group::with('users')->get();

    	return Inertia::render('Groups/Index',[
    		'groups' => $groups,
    	]);
    }
    public function store(ObjectRequest $request)
    {   
    	$group = Group::create([
            'name' => $request->group_name,
            'description' => $request->description,
            'account_id' => 1,
            'editors' => json_encode([Auth::user()->id]),
        ]);

        return $this->show($group);    
    }

    public function show(Group $group){
        return Inertia::render('Groups/Show',[
            'group' => Group::find($group->id),
            'members' => GroupUser::getUsers($group->id)
        ]);
    }

    public function saveUsers(ObjectRequest $request)
    {   
        $x = GroupUser::where('group_id', $request->group_id)->get();

        foreach($x as $y) {
           $y->delete();     
        }

        foreach($request->users as $user) {
            GroupUser::create([
                'group_id' => $request->group_id,
                'user_id' => $user['id'],
            ]);
        }
    }
}