<template>
	<div>
		
	</div>
</template>
<script>
import { Chat } from 'vue-quick-chat'
import 'vue-quick-chat/dist/vue-quick-chat.css';

export default {
  components: {
    Chat
  },
}
	
</script>