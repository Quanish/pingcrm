<template>
  <div>
    <div class="flex flex-row justify-between">
      <h1 class="mb-8 font-bold text-2xl">Мои задачи</h1>
      <inertia-link class="login_button rounded-full text-white h-8 w-1/5 flex justify-center items-center" :href="route('tasks.create')">
        <span>Новая</span>
        <span class="hidden md:inline">Задача</span>
      </inertia-link>
      <div class="flex flex-row gap-2">
        <p class="task-button rounded-full text-white h-8 w-auto p-2 flex justify-center items-center">сегодня 
          <svg class="w-2 h-2 fill-white md:ml-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 961.243 599.998">
              <path d="M239.998 239.999L0 0h961.243L721.246 240c-131.999 132-240.28 240-240.624 239.999-.345-.001-108.625-108.001-240.624-240z" />
            </svg>
        </p>
        <p class="task-button rounded-full text-white w-8 h-8 flex pl-2 items-center">2</p>
      </div>  
      <div class="bg-gray-300 rounded-full p-3 h-8 flex justify-between gap-3 items-center">
        <p>срочно</p>
        <div class="w-6 h-6 border-2 rounded-full"></div>
      </div>
      <img class="h-10" src="img/message.png">
    </div>
    <div class="flex flex-row justify-start gap-5">

    </div>
    <div class="mb-6 flex justify-between items-center">
   
      
    </div>
    <div class="bg-white rounded-md shadow overflow-x-auto">
    	<table class="w-full whitespace-nowrap">
	    	<tr class="text-left font-bold">

            <th class="px-6 pt-6 pb-4">
              <p class="flex justify-between items-center text-gray-500 w-30 h-6 pl-2 pr-2 bg-gray-100 rounded-full">активные 
                <svg class="w-2 h-2 fill-black md:ml-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 961.243 599.998">
                    <path d="M239.998 239.999L0 0h961.243L721.246 240c-131.999 132-240.28 240-240.624 239.999-.345-.001-108.625-108.001-240.624-240z" />
                  </svg>
              </p>
            </th>
            <th class="px-6 pt-6 pb-4">Статус</th>
	          <th class="px-6 pt-6 pb-4">Старт</th>
            <th class="px-6 pt-6 pb-4">Дедлайн</th>
	          
	        </tr>
	        <tr v-for="task in tasks" class="hover:bg-gray-100 focus-within:bg-gray-100 mb-3">
	       	   <td class="pl-5" v-if="task.title">
               <inertia-link :href="route('tasks.edit', task.id)">
                {{task.title}}<p class="text-sm text-gray-300">2 дн. до дедлайна</p><div class="bg-red-300 h-1 w-auto  mr-3"></div>
                </inertia-link>
              </td>
               
             <td><p class="flex justify-between items-center text-white w-24 h-6 pl-2 pr-2 ml-5 task-button rounded-full">в работе 
                <svg class="w-2 h-2 fill-white md:ml-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 961.243 599.998">
                    <path d="M239.998 239.999L0 0h961.243L721.246 240c-131.999 132-240.28 240-240.624 239.999-.345-.001-108.625-108.001-240.624-240z" />
                  </svg>
              </p></td>
             <td class="px-6 pt-6 pb-4">{{task.date_created}}</td>
             <td class="px-6 pt-6 pb-4">{{task.deadline}}</td>
             
             
             
	       	</tr>
    	</table>
    </div>
  </div>
</template>


<script>
import Icon from '@/Shared/Icon'
import pickBy from 'lodash/pickBy'
import Layout from '@/Shared/Layout'
import throttle from 'lodash/throttle'
import mapValues from 'lodash/mapValues'
import Pagination from '@/Shared/Pagination'
import SearchFilter from '@/Shared/SearchFilter'

export default {
  metaInfo: { title: 'Задачи' },
  components: {
    Icon,
    Pagination,
    SearchFilter,
  },
  layout: Layout,
  props: {
    tasks: Array,
    filters: Object,
  },
  data() {
    return {
      form: {
        
        search: this.filters.search,
        trashed: this.filters.trashed,
      },
    }
  },
  watch: {
    form: {
      handler: throttle(function() {
        let query = pickBy(this.form)
        this.$inertia.replace(this.route('tasks', Object.keys(query).length ? query : { remember: 'forget' }))
      }, 150),
      deep: true,
    },
  },
  methods: {
    reset() {
      this.form = mapValues(this.form, () => null)
    },
  },
}
</script>

