<template>
  <div>
   	Проверка
  </div>
</template>


<script>
import Icon from '@/Shared/Icon'
import Layout from '@/Shared/Layout'


export default {
  metaInfo: { title: 'Задачи' },
  
  layout: Layout,
}
</script>

