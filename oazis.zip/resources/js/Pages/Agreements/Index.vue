<template>
  <div>
    <h1 class="mb-8 font-bold text-3xl">Договоры</h1>
  </div>
</template>

<script>
import Layout from '@/Shared/Layout'

export default {
  metaInfo: { title: 'Договоры' },
  layout: Layout,
}
</script>
