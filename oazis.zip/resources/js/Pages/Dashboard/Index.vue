<template>
  <div>
    <div class="flex flex-row justify-between">
      <h1 class="mb-8 font-bold text-2xl">Добрый день,  <span>{{ $page.props.auth.user.first_name}}</span>
                    <span class="hidden md:inline">{{ $page.props.auth.user.last_name }}</span>!</h1>
      <img class="h-10" src="img/message.png">
    </div>
    <div class="flex flex-row justify-between">
   <div class="bg-white rounded-md shadow overflow-x-auto w-1/4 h-96 px-6 py-4 mx-4">
    <div class="flex justify-between">
      <p class="mt-3">Задачи</p> 
      <div class="relative inline-flex">
        <svg class="w-2 h-2 absolute top-0 right-0 m-4 pointer-events-none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 412 232"><path d="M206 171.144L42.678 7.822c-9.763-9.763-25.592-9.763-35.355 0-9.763 9.764-9.763 25.592 0 35.355l181 181c4.88 4.882 11.279 7.323 17.677 7.323s12.796-2.441 17.678-7.322l181-181c9.763-9.764 9.763-25.592 0-35.355-9.763-9.763-25.592-9.763-35.355 0L206 171.144z" fill="#648299" fill-rule="nonzero"/></svg>
        <select v-on:change="changeItem($event)" v-model="mydate" class="border border-gray-300 rounded-full text-gray-600 h-10 pl-5 pr-10 bg-white hover:border-gray-400 focus:outline-none appearance-none">
          <option>сегодня</option>
          <option>месяц</option>
          <option>год</option>
          <option>все время</option>
        </select>
      </div>
      <p class="task-button rounded-full text-white w-10 flex justify-center  items-center">2</p>
    </div>
    <hr class="my-2">
    <div v-for="task in mytasks">
      <div>
        <inertia-link class="py-4 flex items-center w-full justify-between focus:text-indigo-500" :href="route('tasks.show', task.id)"  >
            <div class="flex flex-col">{{task.title}}<p class="text-sm font-normal text-gray-300">2 дня до дедлайна</p></div><p class="task-button-working rounded-full text-white  flex p-3 items-center">{{task.status}}</p>
          <icon v-if="task.deleted_at" name="trash" class="flex-shrink-0 w-3 h-3 fill-gray-400 ml-2" />

          
        </inertia-link>
        <div v-if="new Date(task.deadline) < Date.now()" class="w-full bg-red-500 rounded-full h-1"></div>
        <div v-else class="w-full bg-green-500 rounded-full h-1"></div>
      </div>
    </div>
   </div>
   <div class="bg-white rounded-md shadow overflow-x-auto w-1/4 h-96 px-6 py-4 mx-4">
    <div class="flex justify-between">
      <p class="mt-3">Дела</p> 
      <div class="relative inline-flex">
        <svg class="w-2 h-2 absolute top-0 right-0 m-4 pointer-events-none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 412 232"><path d="M206 171.144L42.678 7.822c-9.763-9.763-25.592-9.763-35.355 0-9.763 9.764-9.763 25.592 0 35.355l181 181c4.88 4.882 11.279 7.323 17.677 7.323s12.796-2.441 17.678-7.322l181-181c9.763-9.764 9.763-25.592 0-35.355-9.763-9.763-25.592-9.763-35.355 0L206 171.144z" fill="#648299" fill-rule="nonzero"/></svg>
        <select class="border border-gray-300 rounded-full text-gray-600 h-10 pl-5 pr-10 bg-white hover:border-gray-400 focus:outline-none appearance-none">
          <option>сегодня</option>
          <option>месяц</option>
          <option>год</option>
          <option>все время</option>
        </select>
      </div>
      <p class="task-button rounded-full text-white w-10 flex justify-center  items-center">3</p>
    </div>
    <hr class="my-2">
    <div v-for="project in projects" class="flex justify-start gap-2">
      <div class="rounded-full w-5 h-5 mb-3 border-2 bg-green-500"></div>{{project}}
    </div>
    <div class="flex flex-row"><div class="rounded-full w-5 h-5 mb-3 border-2 bg-white-500"></div><button v-on:click="create" class="mb-3 ml-2">Добавить</button></div>
   </div>

   <div class="bg-white rounded-md shadow overflow-x-auto w-1/4 h-96 px-6 py-4 mx-4">
    <div class="flex justify-between">
      <p class="mt-3">Встречи</p> 
      <div class="relative inline-flex">
        <svg class="w-2 h-2 absolute top-0 right-0 m-4 pointer-events-none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 412 232"><path d="M206 171.144L42.678 7.822c-9.763-9.763-25.592-9.763-35.355 0-9.763 9.764-9.763 25.592 0 35.355l181 181c4.88 4.882 11.279 7.323 17.677 7.323s12.796-2.441 17.678-7.322l181-181c9.763-9.764 9.763-25.592 0-35.355-9.763-9.763-25.592-9.763-35.355 0L206 171.144z" fill="#648299" fill-rule="nonzero"/></svg>
        <select class="border border-gray-300 rounded-full text-gray-600 h-10 pl-5 pr-10 bg-white hover:border-gray-400 focus:outline-none appearance-none">
          <option>сегодня</option>
          <option >месяц</option>
          <option>год</option>
          <option>все время</option>
        </select>
      </div>
      <p class="task-button rounded-full text-white w-10 flex justify-center  items-center">1</p>
    </div>
    <hr class="my-2">
    <p class="notification">Берик, 12:00, Орынбаева 33</p>
    <div class="flex flex-row"><button  v-on:click="create" class="mt-3 ml-2">Добавить</button></div>
   </div>

   <div class="bg-white rounded-md shadow overflow-x-auto w-1/4 h-96 px-6 py-4 mx-4">
    <div class="flex justify-start">
      События 
      
    </div><br>
    <hr class="my-2">
    <div class="border-2 rounded-lg p-1 flex flex-col">
      <div class="flex flex-row"><img class="h-8" src="img/user1.webp"><div class="flex flex-col  ml-2"><p>Kuanish Aitimov</p><p class="text-sm text-gray-300">Сотрудник</p></div></div>
      <p class="mt-3">Назначил вас ответсвенным по задаче "проект 'Ресторан'"</p>
      <div class="flex flex-row justify-between mt-3">
        <button class="hover:underline rounded-full  p-3 bg-gray-100 text-gray-400">Связаться</button>
        <button class="hover:underline rounded-full  p-3 bg-gray-100 text-gray-400">Перейти к задаче</button>
      </div>
    </div>
    <div class="border-2 rounded-lg p-1 flex flex-col mt-2">
      <div class="flex flex-row"><img class="h-8" src="img/default-user.png"><div class="flex flex-col ml-2"><p>John Doe</p><p class="text-sm text-gray-300">Менеджер</p></div></div>
      <p class="mt-3">Назначил вас ответсвенным по задаче "проект 'Гостиница'"</p>
      <div class="flex flex-row justify-between mt-3">
        <button class="hover:underline rounded-full h-8 p-2 bg-gray-100 text-gray-400">Связаться</button>
        <button class="hover:underline rounded-full h-8 p-2 bg-gray-100 text-gray-400">Перейти к задаче</button>
      </div>
    </div>
   </div>

   </div>
  </div>
</template>

<script>
import Layout from '@/Shared/Layout'
import RadialProgressBar from 'vue-radial-progress'

export default {
  metaInfo: { title: 'Dashboard' },
  layout: Layout,
  data () {
    return {
      mytasks: [],
      mydate:'',
      date : Date.now(),
      timestamp : "",
      completedSteps: 0,
      totalSteps: 10,
      projects:
      [
        'Озеленение','Гостиница','Ресторан',
      ]
    }
  },
  props: {
    tasks: Array,
  },
  components:{
    RadialProgressBar
  },
  computed:{

  },
  methods:{
    create(){
      this.$inertia.get(this.route('tasks.create'))
    },
    checkDeadline(date)
    {
        if(date > this.date){

          return true;
        }
        else{
          this.index -= 1;
          return false;
        }
    },
    changeItem: function changeItem(event) {
     
      switch (String(event.target.value)) {
        case "месяц":
          this.mytasks.splice(0);
          var date = new Date();
          date.setDate(date.getDate()+30);
          //this.mytasks.pop(0);
          //console.log(this.mytasks.filter(x => new Date(x.deadline) < Date.now()))
          var month = this.tasks.filter(x => new Date(x.deadline) < date);
          
          for (var i = month.length - 1; i >= 0; i--) {
            this.mytasks.push(month[i]);
          }
          console.log(this.mytasks);
          
          
          break;
        case "год":
          this.mytasks.splice(0);
          var date = new Date();
          date.setDate(date.getDate()+300);
          //this.mytasks.pop(0);
          //console.log(this.mytasks.filter(x => new Date(x.deadline) < Date.now()))
          var month = this.tasks;
          
          for (var i = month.length - 1; i >= 0; i--) {
            this.mytasks.push(month[i]);
          }
          console.log(this.mytasks);
          
          break;
        case "сегодня":
          this.mytasks.splice(0);
          var date = Date.now();
          //this.mytasks.pop(0);
          //console.log(this.mytasks.filter(x => new Date(x.deadline) < Date.now()))
          var month = this.tasks.filter(x => new Date(x.deadline) > date);
          
          for (var i = month.length - 1; i >= 0; i--) {
            this.mytasks.push(month[i]);
          }
          console.log(this.mytasks);
          
          break;
        default:
          this.mytasks.splice(0);
          
          //this.mytasks.pop(0);
          //console.log(this.mytasks.filter(x => new Date(x.deadline) < Date.now()))
          var month = this.tasks;
          
          for (var i = month.length - 1; i >= 0; i--) {
            this.mytasks.push(month[i]);
          }
          console.log(this.mytasks);
          
      }
    }
  }
}
</script>
