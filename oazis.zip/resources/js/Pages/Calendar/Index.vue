<template>
  <div id="app">
    <h1 class="mb-8 font-bold text-3xl">Календарь</h1>
    <Fullcalendar :options="calendarOptions" :header="{
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'

          }" />


  </div>
</template>



<script>

import Layout from '@/Shared/Layout'
import Fullcalendar from '@fullcalendar/vue'
import dayGridPlugin from '@fullcalendar/daygrid'
import TimeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction'
import ListPlugin from '@fullcalendar/list'

export default {
props:{
    event: Array,
    task: Array,
},
data() {
    return {
       calendarOptions: {
          plugins: [ dayGridPlugin, interactionPlugin ],
          initialView: 'dayGridMonth',
          selectable:true,
          events: []
        },
      }
  },
  metaInfo: { title: 'Календарь' },
  layout: Layout,
  components:{
    Fullcalendar
  },
  created() {
    let arr = []
    console.log(this.task);
    this.event.forEach((item, index) => {
         console.log(this.task);
        this.calendarOptions.events.push({
          title: this.task.first_name,
          start: item.start,
          end: item.end,
          extendedProps: {
            department: 'BioChemistry'
          },
          description: 'Lecture'
       
        })
    });
  }
}
</script>
